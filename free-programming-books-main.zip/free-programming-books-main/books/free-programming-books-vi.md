### Index

* [Go](#golang)
* [Học máy](#machine-learning)


### <a id="golang"></a>Go

* [The Little Go Book](https://github.com/nainglinaung/the-little-go-book) - Karl Seguin, `trl.:` Naing Lin Aung ([HTML](https://github.com/quangnh89/the-little-go-book/blob/master/vi/go.md))


### <a id="machine-learning"></a>Học máy

* [Đắm chìm vào Học sâu](https://d2l.aivivn.com) - `trl.:` Nhóm dịch thuật Đắm chìm vào Học sâu (HTML)

