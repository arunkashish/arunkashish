### Index

* [Ajax](#ajax)
* [C](#c)
* [HTML and CSS](#html-and-css)
* [Javascript](#javascript)
* [MySQL](#mysql)
* [PHP](#php)
* [Scratch](#scratch)


### Ajax

* [Ajax](http://etutoriale.ro/articles/1483/1/Tutorial-Ajax/)


### C

* [Ghidul Beej pentru Programarea in Retea - Folosind socket de internet](https://web.archive.org/web/20180710112954/http://weknowyourdreams.com/beej.html) - Brian "Beej Jorgensen" Hall, Dragos Moroianu (HTML) *(:card_file_box: archived)*


### HTML and CSS

* [HTML](http://tutorialehtml.com/ro/introducere-in-html/)


### MySQL

* [MySQL](http://profs.info.uaic.ro/~busaco/teach/courses/net/docs/mysql-ro.pdf) (PDF)


### PHP

* [PHP](http://php.punctsivirgula.ro)


### Scratch

* [Informatica Creativa](http://scratched.gse.harvard.edu/resources/informatica-creativa-0)


### Javascript

* [Curs si Tutoriale JavaScript](https://marplo.net/javascript)
