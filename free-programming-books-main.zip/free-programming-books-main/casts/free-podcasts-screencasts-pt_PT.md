### Index

* [Desenvolvimento Web](#desenvolvimento-web)
* [Laravel](#laravel)
* [Ubuntu](#ubuntu)


### Desenvolvimento Web

* [10webPodcast sobre web e desenvolvimento em português](https://10web.pt/acerca) - Ricardo Correia, Vitor Silva, Ana Sampaio (podcast)


### Laravel

* [Laravel Portugal Live](https://laravelportugal.simplecast.fm) (screencast)


### Ubuntu

* [O Podcast Ubuntu Portugal](https://podcastubuntuportugal.org) (podcast)
