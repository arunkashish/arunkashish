### Index

* [Niezależne od języka programowania](#niezale%C5%BCne-od-j%C4%99zyka-programowania)


### Niezależne od języka programowania

* [Better Software Design](https://bettersoftwaredesign.pl) - Mariusz Gil (podcast)
* [Biznes Myśli](https://www.youtube.com/playlist?list=PLYQwwHlHNdgjSEgrmGv0fbHuxd5p7f5qA) - Vladimir Alekseichenko (podcast)
* [Chwila Dla Admina](https://www.youtube.com/playlist?list=PLdHokABybL4nu6h5C3ig4XSG2Ni6XeED0) - Artur Molendowski (podcast)
* [Dev Env](https://devenv.pl/podcast) - Adrian Piętka, Bartłomiej Michalski, Mateusz Konieczny (podcast)
* [DevTalk](https://devstyle.pl/category/podcast)
* [Piątki po deployu](https://piatkipodeployu.pl) - Mateusz Anioła, Miłosz Kusiciel (podcast)
* [Porozmawiajmy o IT](https://porozmawiajmyoit.pl) - Krzysztof Kempiński (podcast)
* [Przeprogramowani](https://anchor.fm/przeprogramowani) - Przemek Smyrdek, Marcin Czarkowski (podcast)
* [Rozmowa Kontrolowana](https://www.youtube.com/playlist?list=PLTKLAGr6FHxOcW4NRX3BCkU7Zml92WU1u) - Zaufana Trzecia Strona (screencast)
