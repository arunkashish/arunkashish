### Index

* [C++](#cpp)
* [Go](#go)
* [Java](#java)
* [PHP](#php)
* [Python](#python)


### Рівні

BEG - Hовачок. Основи.       
INT - Середній. Розширені можливості.       
ADV - Просунутий. Тонкощі.


### <a id="cpp"></a>C++

* [Мова програмування C++](https://stepik.org/course/67114) - Александр Руденко (Stepik) (BEG)


### Go

* [Go (Golang) - перше знайомство (українською)](https://stepik.org/course/171599) - Ігор Лютий (Stepik) (BEG)


### Java

* [Основи програмування на Java](https://courses.prometheus.org.ua/courses/EPAM/JAVA101/2016_T2/about)


### PHP

* [PHP - перше знайомство](https://stepik.org/course/125585) - Ігор Лютий (Stepik) (BEG)


### Python

* [Python 2: Курс Молодого Бійця](http://www.vitaliypodoba.com/tutorials/python2-beginners-course/) - Віталій Подоба
* [Мова програмування Python](https://stepik.org/course/101696) - Александр Руденко (Stepik) (BEG)
* [Основи програмування на Python](https://courses.prometheus.org.ua/courses/KPI/Programming101/2015_T1/about) - Нікіта Павлюченко (email address *required*, phone number *required*)
* [Програмування на мові Python (3.x). Початковий курс](http://web.archive.org/web/20201026152235/https://sites.google.com/site/pythonukr/vstup) *(:card_file_box: archived)*
* [Основи програмування. Python. Частина 1 - КПІ](https://ela.kpi.ua/handle/123456789/25111) - А.В. Яковенко
