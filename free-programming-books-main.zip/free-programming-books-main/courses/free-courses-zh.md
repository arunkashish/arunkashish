### Index

* [0 - MOOC](#0---mooc)
* [AI](#ai)
* [Flutter](#flutter)
* [Linux](#linux)
* [OS](#os)
* [Python](#python)


### 0 - MOOC

* [freeCodeCamp](https://chinese.freecodecamp.org)


### AI

* [动手学深度学习](https://zh.d2l.ai/index.html) - d2lzh
* [机器学习速成课程](https://developers.google.com/machine-learning/crash-course/prereqs-and-prework?hl=zh-cn) - 谷歌出品


### Flutter

* [Flutter 仿微信朋友圈](https://www.youtube.com/playlist?v=7lZRWWELIaA&list=PL274L1n86T80VQcJb76zcXcPpF-S-fFV-) - ducafecat


### Linux

* [Linux 核心設計](https://youtube.com/playlist?list=PL6S9AqLQkFpongEA75M15_BlQBC9rTdd8) - jserv
* [Linux 教程 CentOS 从入门到精通](https://www.youtube.com/playlist?list=PL9nxfq1tlKKlImsI9_iDguCUOhLFGamKI) - Jomy King


### OS

* [操作系统原理](https://www.youtube.com/playlist?list=PLkl2qqmYigA66rJ4FgmZan4YIVRgNFLQx) - 从0开始数
* [操作系统原理 清华大学](https://www.youtube.com/playlist?list=PLgSjsxruwagoYuFuMnUY-lMzTfQR7ugw9) - 自我学习Evan


### Python

* [最新Python编程教程19天从入门到精通](https://www.youtube.com/playlist?list=PLVyDH2ns1F75k1hvD2apA0DwI3XMiSDqp) - 知知识改变命运
