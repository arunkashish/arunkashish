### Index

* [C#](#csharp)
* [Other](#other)
* [Python](#python)
* [Web Development](#web-development)


### <a id="csharp"></a>C\#

* [Jyväskylän yliopiston C#-kieli ohjelmointikurssi](https://tim.jyu.fi/view/kurssit/tie/ohj1/moniste/Ohjelmointi-1) - Ilmainen verkkokurssi


### Other

* [Elements of AI](https://www.elementsofai.com/fi/) - Tekoälykurssi
* [Koodiaapinen](https://koodiaapinen.fi) - Opettajille suunnattu sivusto ohjelmoinnin maailmaan.
* [Mooc](https://mooc.fi) - Laadukkaita, avoimia ja ilmaisia verkkokursseja kaikille
* [Ohjelmointi](https://fitech.io/fi/ohjelmointi/) - FITech


### Python

* [Ohjelmoinnin perusteet ja jatkokurssi](https://ohjelmointi-25.mooc.fi) - Helsingin yliopisto


### Web Development

* [Full stack open](https://fullstackopen.com) - University of Helsinki
* [Web-ohjelmointi](https://fitech.io/fi/web-ohjelmointi/) - FITech
